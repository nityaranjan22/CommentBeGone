# commentbegone/__init__.py

from .remove_comments import remove_comments_from_text

__all__ = ['remove_comments_from_text']
